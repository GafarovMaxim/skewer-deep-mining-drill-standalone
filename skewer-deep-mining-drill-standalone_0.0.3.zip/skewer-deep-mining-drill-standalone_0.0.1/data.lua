require("__skewer-deep-mining-drill-standalone__.prototypes.entity")
require("__skewer-deep-mining-drill-standalone__.prototypes.item")
require("__skewer-deep-mining-drill-standalone__.prototypes.technology")
require("__skewer-deep-mining-drill-standalone__.prototypes.recipe")